import { Router } from 'express';
import * as c from '../controllers/booking.controller';
import { requireAuth, optionalAuth } from '../middlewares/auth';
import { authorize } from '../middlewares/authorize';
import { Permission } from '../utils/auth/roles';
import {
  validateBookingHold,
  validateIdParam,
  handleValidationErrors,
} from '../middlewares/validation';

const r = Router();

/** Public (hoặc yêu cầu đăng nhập tuỳ bạn) */
r.post(
  '/hold',
  requireAuth,
  validateBookingHold,
  handleValidationErrors,
  c.holdSeats,
);

r.get(
  '/:id',
  optionalAuth,
  validateIdParam,
  handleValidationErrors,
  c.getBooking,
);

r.get('/mine', requireAuth, handleValidationErrors, c.listMine);

/** Admin/Dev helpers */
r.post(
  '/:id/cancel',
  requireAuth,
  authorize(Permission.MANAGE_BOOKINGS),
  validateIdParam,
  handleValidationErrors,
  c.cancelBooking,
);

r.post(
  '/:id/mark-paid',
  requireAuth,
  authorize(Permission.MANAGE_BOOKINGS),
  validateIdParam,
  handleValidationErrors,
  c.markPaid,
);

export default r;
