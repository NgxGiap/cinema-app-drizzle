import { NextFunction, Request, Response } from 'express';
import * as svc from '../services/booking.service';

export async function holdSeats(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const userId = req.user?.id || req.body.userId;
    if (!userId) {
      return res.fail('Bạn cần đăng nhập để giữ ghế', 401);
    }
    const payload: svc.HoldSeatsInput = {
      showtimeId: String(req.body.showtimeId),
      seatIds: Array.isArray(req.body.seatIds)
        ? req.body.seatIds.map(String)
        : [],
      userId: String(userId),
    };
    const result = await svc.holdSeats(payload);
    return res.ok(result, 'Seats held for 5 minutes');
  } catch (err) {
    next(err);
  }
}

export async function getBooking(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const data = await svc.getById(String(req.params.id));
    return res.ok(data, 'Booking detail');
  } catch (err) {
    next(err);
  }
}

export async function listMine(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const page = Number(req.query.page) || 1;
    const pageSize = Number(req.query.pageSize) || 20;
    const data = await svc.list(page, pageSize, {
      userId: String(req.user!.id),
    });
    return res.ok(data, 'My bookings');
  } catch (err) {
    next(err);
  }
}

export async function cancelBooking(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const data = await svc.cancel(String(req.params.id));
    return res.ok(data, 'Booking canceled');
  } catch (err) {
    next(err);
  }
}

export async function markPaid(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    await svc.finalizeBookingSeats(req.params.id);
    return res.ok({ ok: true }, 'Booking marked as PAID & tickets issued');
  } catch (err) {
    next(err);
  }
}
